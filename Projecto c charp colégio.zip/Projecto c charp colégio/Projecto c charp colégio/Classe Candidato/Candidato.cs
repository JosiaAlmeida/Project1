﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Projecto_c_charp_colégio
{
    class Candidato
    {
        private string nome;
        private string curso;
        private string sexo;
        private string BI;
        private string idade;

           
        public Candidato(string nome, string curso, string sexo,string BI, string idade)
        {
            this.nome = nome;
            this.curso = curso;
            this.sexo = sexo;
            this.BI = BI;
            this.idade = idade;

            ler();
            
            verificar01();

        }

        private void ler()
        {
            Dados_Cadidatos.nomes.Add(this.nome);
            Dados_Cadidatos.cursos.Add(this.curso);
            Dados_Cadidatos.sexo.Add(this.sexo);
            Dados_Cadidatos.BI.Add(this.BI);
            Dados_Cadidatos.idades.Add(this.idade);
            Dados_Cadidatos.NumeroInscricao.Add(geradorCodigo());
          
           
            MessageBox.Show("Inscrito com sucesso","Informação");
            MessageBox.Show("O seu número de ordem é " +geradorCodigo());
            
        }
        private void verificar01()
        {
           
            //for(int i = 0; i < Dados_Cadidatos.nomes.Count; i++)
            //{
            //    MessageBox.Show(Dados_Cadidatos.nomes[i].ToString());

            //}


        }
        public int geradorCodigo()
        {
            int id = 0,c=0;

            for(int i = 0; i < Dados_Cadidatos.nomes.Count; i++)
            {
                id = c+1;
                
               
                c++;

            }
              
           
            return id;

        }
    }
}
