﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Projecto_c_charp_colégio
{
    public partial class ListarCandidatos : Form
    {
        public ListarCandidatos()
        {
            InitializeComponent();
        }

        private void ListarCandidatos_Load(object sender, EventArgs e)
        {
            datagridview.Rows.Add(Dados_Cadidatos.nomes.Count);
             
                mostrar();
           
          

             
            
        }

        private void mostrar()
        {
            for(int i = 0; i < Dados_Cadidatos.nomes.Count; i++)
            { 
                datagridview[0,i].Value = Dados_Cadidatos.nomes[i].ToString();
                datagridview[1,i].Value = Dados_Cadidatos.cursos[i].ToString();
                datagridview[2,i].Value = Dados_Cadidatos.sexo[i].ToString();
                datagridview[3,i].Value = Dados_Cadidatos.BI[i].ToString();
                datagridview[4,i].Value = Dados_Cadidatos.idades[i].ToString();
                datagridview[5,i].Value = Dados_Cadidatos.NumeroInscricao[i].ToString();
                 
            }
        }
        
        private void panel3_Paint(object sender, PaintEventArgs e)
        {

        }
    }
}
