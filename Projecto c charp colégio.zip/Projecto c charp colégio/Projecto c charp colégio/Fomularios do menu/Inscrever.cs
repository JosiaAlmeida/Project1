﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Projecto_c_charp_colégio
{
    public partial class Inscrever : Form
    {
        bool verificar;

        public Inscrever()
        {
            InitializeComponent();
        }

      
        private void verif()
        {
            int idade = 0;

            try{
                idade = int.Parse(txt_idade.Text);
                if(idade>=12 && idade <= 20)
                {
                    verificar = true;
                }
                else
                {
                    verificar = false;
                    MessageBox.Show("A sua idade não está nos intervalos de 12 a 20 anos ","Informação",MessageBoxButtons.OK,MessageBoxIcon.Exclamation);
                }
            }catch(Exception e)
            {
                MessageBox.Show("Erro não digite caracter neste campo");
            }
        }
        private string sexo()
        {
            if (rb_masculino.Checked == true)
            {
                return "Masculino";
            }
            if (rb_feminino.Checked == true)
            {
                return "Feminino";
            }
            else
            {
                return " ";
            }
            
        }

        private void txt_idade_TextChanged(object sender, EventArgs e)
        {

        }

        private void label6_Click(object sender, EventArgs e)
        {

        }

        private void rb_femenino_CheckedChanged(object sender, EventArgs e)
        {

        }

        private void rb_masculino_CheckedChanged(object sender, EventArgs e)
        {

        }

        private void cmb_cursos_SelectedIndexChanged(object sender, EventArgs e)
        {

        }

        private void txt_BI_TextChanged(object sender, EventArgs e)
        {

        }

        private void label5_Click(object sender, EventArgs e)
        {

        }

        private void label4_Click(object sender, EventArgs e)
        {

        }

        private void label3_Click(object sender, EventArgs e)
        {

        }

        private void txt_nome_TextChanged(object sender, EventArgs e)
        {

        }

        private void label2_Click(object sender, EventArgs e)
        {

        }

        private void btn_inscrever_Click_1(object sender, EventArgs e)
        {
            string nome = txt_nome.Text;
            string curso = cmb_cursos.Text;
            string Bi = txt_BI.Text;
            string idade = txt_idade.Text;
            string sex = sexo();

            verif();
            if (verificar == true)
            {
                if (txt_nome.Text != "" && cmb_cursos.Text != "" && txt_BI.Text != "" && txt_idade.Text != "" && sex != "")
                {
                    Candidato candidato = new Candidato(nome, curso, sex, Bi, idade);

                }
                else
                {
                    MessageBox.Show("Por favor preencha todos os campos", "Informação", MessageBoxButtons.OK, MessageBoxIcon.Exclamation);
                }

            }
        }
    }
}
