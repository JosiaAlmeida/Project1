﻿namespace Projecto_c_charp_colégio
{
    partial class Estatistica
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(Estatistica));
            this.panel3 = new System.Windows.Forms.Panel();
            this.panel1 = new System.Windows.Forms.Panel();
            this.label7 = new System.Windows.Forms.Label();
            this.panel2 = new System.Windows.Forms.Panel();
            this.label4 = new System.Windows.Forms.Label();
            this.pb_homens = new Bunifu.Framework.UI.BunifuCircleProgressbar();
            this.lb_homens = new System.Windows.Forms.Label();
            this.lb_mulheres = new System.Windows.Forms.Label();
            this.pb_mulheres = new Bunifu.Framework.UI.BunifuCircleProgressbar();
            this.label8 = new System.Windows.Forms.Label();
            this.panel3.SuspendLayout();
            this.panel1.SuspendLayout();
            this.SuspendLayout();
            // 
            // panel3
            // 
            this.panel3.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(64)))), ((int)(((byte)(64)))), ((int)(((byte)(64)))));
            this.panel3.Controls.Add(this.lb_mulheres);
            this.panel3.Controls.Add(this.pb_mulheres);
            this.panel3.Controls.Add(this.label8);
            this.panel3.Controls.Add(this.lb_homens);
            this.panel3.Controls.Add(this.pb_homens);
            this.panel3.Controls.Add(this.label4);
            this.panel3.Location = new System.Drawing.Point(0, 124);
            this.panel3.Name = "panel3";
            this.panel3.Size = new System.Drawing.Size(477, 302);
            this.panel3.TabIndex = 16;
            this.panel3.Paint += new System.Windows.Forms.PaintEventHandler(this.panel3_Paint);
            // 
            // panel1
            // 
            this.panel1.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(0)))), ((int)(((byte)(30)))));
            this.panel1.Controls.Add(this.label7);
            this.panel1.Controls.Add(this.panel2);
            this.panel1.Location = new System.Drawing.Point(0, -16);
            this.panel1.Name = "panel1";
            this.panel1.Size = new System.Drawing.Size(477, 303);
            this.panel1.TabIndex = 15;
            // 
            // label7
            // 
            this.label7.AutoSize = true;
            this.label7.Font = new System.Drawing.Font("Candara", 18F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label7.ForeColor = System.Drawing.Color.White;
            this.label7.Location = new System.Drawing.Point(208, 67);
            this.label7.Name = "label7";
            this.label7.Size = new System.Drawing.Size(147, 29);
            this.label7.TabIndex = 2;
            this.label7.Text = "ESTÁTISTICA";
            // 
            // panel2
            // 
            this.panel2.BackColor = System.Drawing.Color.White;
            this.panel2.BackgroundImage = ((System.Drawing.Image)(resources.GetObject("panel2.BackgroundImage")));
            this.panel2.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.panel2.Location = new System.Drawing.Point(14, 25);
            this.panel2.Name = "panel2";
            this.panel2.Size = new System.Drawing.Size(107, 106);
            this.panel2.TabIndex = 1;
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.Font = new System.Drawing.Font("Candara", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label4.ForeColor = System.Drawing.Color.White;
            this.label4.Location = new System.Drawing.Point(64, 65);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(143, 19);
            this.label4.TabIndex = 3;
            this.label4.Text = "TOTAL DE HOMENS ";
            // 
            // pb_homens
            // 
            this.pb_homens.animated = false;
            this.pb_homens.animationIterval = 5;
            this.pb_homens.animationSpeed = 300;
            this.pb_homens.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(64)))), ((int)(((byte)(64)))), ((int)(((byte)(64)))));
            this.pb_homens.BackgroundImage = ((System.Drawing.Image)(resources.GetObject("pb_homens.BackgroundImage")));
            this.pb_homens.Font = new System.Drawing.Font("Microsoft Sans Serif", 26.25F);
            this.pb_homens.ForeColor = System.Drawing.Color.White;
            this.pb_homens.LabelVisible = true;
            this.pb_homens.LineProgressThickness = 8;
            this.pb_homens.LineThickness = 5;
            this.pb_homens.Location = new System.Drawing.Point(273, 10);
            this.pb_homens.Margin = new System.Windows.Forms.Padding(10, 9, 10, 9);
            this.pb_homens.MaxValue = 100;
            this.pb_homens.Name = "pb_homens";
            this.pb_homens.ProgressBackColor = System.Drawing.Color.Gainsboro;
            this.pb_homens.ProgressColor = System.Drawing.Color.SeaGreen;
            this.pb_homens.Size = new System.Drawing.Size(144, 144);
            this.pb_homens.TabIndex = 4;
            this.pb_homens.Value = 0;
            // 
            // lb_homens
            // 
            this.lb_homens.AutoSize = true;
            this.lb_homens.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.lb_homens.Font = new System.Drawing.Font("Candara", 18F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lb_homens.ForeColor = System.Drawing.Color.White;
            this.lb_homens.Location = new System.Drawing.Point(235, 60);
            this.lb_homens.Name = "lb_homens";
            this.lb_homens.Size = new System.Drawing.Size(2, 31);
            this.lb_homens.TabIndex = 5;
            // 
            // lb_mulheres
            // 
            this.lb_mulheres.AutoSize = true;
            this.lb_mulheres.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.lb_mulheres.Font = new System.Drawing.Font("Candara", 18F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lb_mulheres.ForeColor = System.Drawing.Color.White;
            this.lb_mulheres.Location = new System.Drawing.Point(234, 214);
            this.lb_mulheres.Name = "lb_mulheres";
            this.lb_mulheres.Size = new System.Drawing.Size(2, 31);
            this.lb_mulheres.TabIndex = 8;
            // 
            // pb_mulheres
            // 
            this.pb_mulheres.animated = false;
            this.pb_mulheres.animationIterval = 5;
            this.pb_mulheres.animationSpeed = 300;
            this.pb_mulheres.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(64)))), ((int)(((byte)(64)))), ((int)(((byte)(64)))));
            this.pb_mulheres.BackgroundImage = ((System.Drawing.Image)(resources.GetObject("pb_mulheres.BackgroundImage")));
            this.pb_mulheres.Font = new System.Drawing.Font("Microsoft Sans Serif", 26.25F);
            this.pb_mulheres.ForeColor = System.Drawing.Color.White;
            this.pb_mulheres.LabelVisible = true;
            this.pb_mulheres.LineProgressThickness = 8;
            this.pb_mulheres.LineThickness = 5;
            this.pb_mulheres.Location = new System.Drawing.Point(273, 149);
            this.pb_mulheres.Margin = new System.Windows.Forms.Padding(10, 9, 10, 9);
            this.pb_mulheres.MaxValue = 100;
            this.pb_mulheres.Name = "pb_mulheres";
            this.pb_mulheres.ProgressBackColor = System.Drawing.Color.Gainsboro;
            this.pb_mulheres.ProgressColor = System.Drawing.Color.SeaGreen;
            this.pb_mulheres.Size = new System.Drawing.Size(144, 144);
            this.pb_mulheres.TabIndex = 7;
            this.pb_mulheres.Value = 0;
            // 
            // label8
            // 
            this.label8.AutoSize = true;
            this.label8.Font = new System.Drawing.Font("Candara", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label8.ForeColor = System.Drawing.Color.White;
            this.label8.Location = new System.Drawing.Point(64, 218);
            this.label8.Name = "label8";
            this.label8.Size = new System.Drawing.Size(155, 19);
            this.label8.TabIndex = 6;
            this.label8.Text = "TOTAL DE MULHERES";
            // 
            // Estatistica
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(477, 425);
            this.Controls.Add(this.panel3);
            this.Controls.Add(this.panel1);
            this.Icon = ((System.Drawing.Icon)(resources.GetObject("$this.Icon")));
            this.MaximizeBox = false;
            this.Name = "Estatistica";
            this.Text = "Estatistica";
            this.Load += new System.EventHandler(this.Estatistica_Load);
            this.panel3.ResumeLayout(false);
            this.panel3.PerformLayout();
            this.panel1.ResumeLayout(false);
            this.panel1.PerformLayout();
            this.ResumeLayout(false);

        }

        #endregion
        private System.Windows.Forms.Panel panel3;
        private System.Windows.Forms.Label lb_mulheres;
        private Bunifu.Framework.UI.BunifuCircleProgressbar pb_mulheres;
        private System.Windows.Forms.Label label8;
        private System.Windows.Forms.Label lb_homens;
        private Bunifu.Framework.UI.BunifuCircleProgressbar pb_homens;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.Panel panel1;
        private System.Windows.Forms.Label label7;
        private System.Windows.Forms.Panel panel2;
    }
}