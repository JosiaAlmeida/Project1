﻿namespace Projecto_c_charp_colégio
{
    partial class Consultar_candidato_mostrar
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(Consultar_candidato_mostrar));
            this.panel3 = new System.Windows.Forms.Panel();
            this.label7 = new System.Windows.Forms.Label();
            this.label8 = new System.Windows.Forms.Label();
            this.label9 = new System.Windows.Forms.Label();
            this.label10 = new System.Windows.Forms.Label();
            this.txt_nome = new WindowsFormsControlLibrary1.BunifuCustomTextbox();
            this.txt_curso = new WindowsFormsControlLibrary1.BunifuCustomTextbox();
            this.txt_sexo = new WindowsFormsControlLibrary1.BunifuCustomTextbox();
            this.txt_BI = new WindowsFormsControlLibrary1.BunifuCustomTextbox();
            this.panel1 = new System.Windows.Forms.Panel();
            this.label11 = new System.Windows.Forms.Label();
            this.panel2 = new System.Windows.Forms.Panel();
            this.label12 = new System.Windows.Forms.Label();
            this.txt_idade = new WindowsFormsControlLibrary1.BunifuCustomTextbox();
            this.panel3.SuspendLayout();
            this.panel1.SuspendLayout();
            this.SuspendLayout();
            // 
            // panel3
            // 
            this.panel3.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(64)))), ((int)(((byte)(64)))), ((int)(((byte)(64)))));
            this.panel3.Controls.Add(this.txt_idade);
            this.panel3.Controls.Add(this.label12);
            this.panel3.Controls.Add(this.label7);
            this.panel3.Controls.Add(this.label8);
            this.panel3.Controls.Add(this.label9);
            this.panel3.Controls.Add(this.label10);
            this.panel3.Controls.Add(this.txt_nome);
            this.panel3.Controls.Add(this.txt_curso);
            this.panel3.Controls.Add(this.txt_sexo);
            this.panel3.Controls.Add(this.txt_BI);
            this.panel3.Location = new System.Drawing.Point(2, 140);
            this.panel3.Name = "panel3";
            this.panel3.Size = new System.Drawing.Size(427, 283);
            this.panel3.TabIndex = 12;
            this.panel3.Paint += new System.Windows.Forms.PaintEventHandler(this.panel3_Paint);
            // 
            // label7
            // 
            this.label7.AutoSize = true;
            this.label7.Font = new System.Drawing.Font("Candara", 14.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label7.ForeColor = System.Drawing.Color.White;
            this.label7.Location = new System.Drawing.Point(56, 185);
            this.label7.Name = "label7";
            this.label7.Size = new System.Drawing.Size(49, 23);
            this.label7.TabIndex = 15;
            this.label7.Text = "Nº BI";
            // 
            // label8
            // 
            this.label8.AutoSize = true;
            this.label8.Font = new System.Drawing.Font("Candara", 14.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label8.ForeColor = System.Drawing.Color.White;
            this.label8.Location = new System.Drawing.Point(56, 145);
            this.label8.Name = "label8";
            this.label8.Size = new System.Drawing.Size(54, 23);
            this.label8.TabIndex = 14;
            this.label8.Text = "SEXO";
            // 
            // label9
            // 
            this.label9.AutoSize = true;
            this.label9.Font = new System.Drawing.Font("Candara", 14.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label9.ForeColor = System.Drawing.Color.White;
            this.label9.Location = new System.Drawing.Point(56, 97);
            this.label9.Name = "label9";
            this.label9.Size = new System.Drawing.Size(68, 23);
            this.label9.TabIndex = 13;
            this.label9.Text = "CURSO";
            // 
            // label10
            // 
            this.label10.AutoSize = true;
            this.label10.Font = new System.Drawing.Font("Candara", 14.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label10.ForeColor = System.Drawing.Color.White;
            this.label10.Location = new System.Drawing.Point(56, 54);
            this.label10.Name = "label10";
            this.label10.Size = new System.Drawing.Size(62, 23);
            this.label10.TabIndex = 12;
            this.label10.Text = "NOME";
            // 
            // txt_nome
            // 
            this.txt_nome.BackColor = System.Drawing.Color.White;
            this.txt_nome.BorderColor = System.Drawing.Color.SeaGreen;
            this.txt_nome.Location = new System.Drawing.Point(180, 59);
            this.txt_nome.Name = "txt_nome";
            this.txt_nome.ReadOnly = true;
            this.txt_nome.Size = new System.Drawing.Size(190, 20);
            this.txt_nome.TabIndex = 11;
            // 
            // txt_curso
            // 
            this.txt_curso.BackColor = System.Drawing.Color.White;
            this.txt_curso.BorderColor = System.Drawing.Color.SeaGreen;
            this.txt_curso.Location = new System.Drawing.Point(181, 101);
            this.txt_curso.Name = "txt_curso";
            this.txt_curso.ReadOnly = true;
            this.txt_curso.Size = new System.Drawing.Size(190, 20);
            this.txt_curso.TabIndex = 10;
            // 
            // txt_sexo
            // 
            this.txt_sexo.BackColor = System.Drawing.Color.White;
            this.txt_sexo.BorderColor = System.Drawing.Color.SeaGreen;
            this.txt_sexo.Location = new System.Drawing.Point(181, 145);
            this.txt_sexo.Name = "txt_sexo";
            this.txt_sexo.ReadOnly = true;
            this.txt_sexo.Size = new System.Drawing.Size(190, 20);
            this.txt_sexo.TabIndex = 9;
            // 
            // txt_BI
            // 
            this.txt_BI.BackColor = System.Drawing.Color.White;
            this.txt_BI.BorderColor = System.Drawing.Color.SeaGreen;
            this.txt_BI.Location = new System.Drawing.Point(181, 188);
            this.txt_BI.Name = "txt_BI";
            this.txt_BI.ReadOnly = true;
            this.txt_BI.Size = new System.Drawing.Size(190, 20);
            this.txt_BI.TabIndex = 8;
            // 
            // panel1
            // 
            this.panel1.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(0)))), ((int)(((byte)(30)))));
            this.panel1.Controls.Add(this.label11);
            this.panel1.Controls.Add(this.panel2);
            this.panel1.Location = new System.Drawing.Point(2, 0);
            this.panel1.Name = "panel1";
            this.panel1.Size = new System.Drawing.Size(427, 303);
            this.panel1.TabIndex = 11;
            // 
            // label11
            // 
            this.label11.AutoSize = true;
            this.label11.Font = new System.Drawing.Font("Candara", 15.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label11.ForeColor = System.Drawing.Color.White;
            this.label11.Location = new System.Drawing.Point(137, 63);
            this.label11.Name = "label11";
            this.label11.Size = new System.Drawing.Size(229, 26);
            this.label11.TabIndex = 2;
            this.label11.Text = "DADOS DO CANDIDATO";
            // 
            // panel2
            // 
            this.panel2.BackColor = System.Drawing.Color.White;
            this.panel2.BackgroundImage = ((System.Drawing.Image)(resources.GetObject("panel2.BackgroundImage")));
            this.panel2.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.panel2.Location = new System.Drawing.Point(14, 17);
            this.panel2.Name = "panel2";
            this.panel2.Size = new System.Drawing.Size(107, 106);
            this.panel2.TabIndex = 1;
            // 
            // label12
            // 
            this.label12.AutoSize = true;
            this.label12.Font = new System.Drawing.Font("Candara", 14.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label12.ForeColor = System.Drawing.Color.White;
            this.label12.Location = new System.Drawing.Point(56, 228);
            this.label12.Name = "label12";
            this.label12.Size = new System.Drawing.Size(61, 23);
            this.label12.TabIndex = 16;
            this.label12.Text = "IDADE";
            // 
            // txt_idade
            // 
            this.txt_idade.BackColor = System.Drawing.Color.White;
            this.txt_idade.BorderColor = System.Drawing.Color.SeaGreen;
            this.txt_idade.Location = new System.Drawing.Point(180, 228);
            this.txt_idade.Name = "txt_idade";
            this.txt_idade.ReadOnly = true;
            this.txt_idade.Size = new System.Drawing.Size(190, 20);
            this.txt_idade.TabIndex = 17;
            // 
            // Consultar_candidato_mostrar
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(425, 421);
            this.Controls.Add(this.panel3);
            this.Controls.Add(this.panel1);
            this.Icon = ((System.Drawing.Icon)(resources.GetObject("$this.Icon")));
            this.MaximizeBox = false;
            this.Name = "Consultar_candidato_mostrar";
            this.Text = "Mostrar Candidato";
            this.Load += new System.EventHandler(this.Consultar_candidato_mostrar_Load);
            this.panel3.ResumeLayout(false);
            this.panel3.PerformLayout();
            this.panel1.ResumeLayout(false);
            this.panel1.PerformLayout();
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.Panel panel3;
        private WindowsFormsControlLibrary1.BunifuCustomTextbox txt_idade;
        private System.Windows.Forms.Label label12;
        private System.Windows.Forms.Label label7;
        private System.Windows.Forms.Label label8;
        private System.Windows.Forms.Label label9;
        private System.Windows.Forms.Label label10;
        private WindowsFormsControlLibrary1.BunifuCustomTextbox txt_nome;
        private WindowsFormsControlLibrary1.BunifuCustomTextbox txt_curso;
        private WindowsFormsControlLibrary1.BunifuCustomTextbox txt_sexo;
        private WindowsFormsControlLibrary1.BunifuCustomTextbox txt_BI;
        private System.Windows.Forms.Panel panel1;
        private System.Windows.Forms.Label label11;
        private System.Windows.Forms.Panel panel2;
    }
}