﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Projecto_c_charp_colégio
{
    public partial class Consultar_candidato_mostrar: Form
    {
        public Consultar_candidato_mostrar()
        {
            InitializeComponent();
        }

        private void Consultar_candidato_mostrar_Load(object sender, EventArgs e)
        {
            mostrar();
        }

        private void mostrar()
        {
            int c = Dados_Cadidatos.pos;
             
            //    lb_nome.Text = Dados_Cadidatos.nomes[c].ToString();
            //    lb_curso.Text = Dados_Cadidatos.cursos[c].ToString();
            //    lb_sexo.Text = Dados_Cadidatos.sexo[c].ToString();
            //    lb_BI.Text = Dados_Cadidatos.BI[c].ToString();
            //    lb_idade.Text = Dados_Cadidatos.idades[c].ToString();
            for(int i = 0; i < Dados_Cadidatos.NumeroInscricao.Count; i++)
            {
                  txt_nome.Text = Dados_Cadidatos.nomes[Dados_Cadidatos.pos].ToString();
                  txt_curso.Text = Dados_Cadidatos.cursos[Dados_Cadidatos.pos].ToString();
                  txt_sexo.Text = Dados_Cadidatos.sexo[Dados_Cadidatos.pos].ToString();
                  txt_BI.Text = Dados_Cadidatos.BI[Dados_Cadidatos.pos].ToString();
                  txt_idade.Text = Dados_Cadidatos.idades[Dados_Cadidatos.pos].ToString();
            }

        }

        private void panel3_Paint(object sender, PaintEventArgs e)
        {

        }
    }
}
