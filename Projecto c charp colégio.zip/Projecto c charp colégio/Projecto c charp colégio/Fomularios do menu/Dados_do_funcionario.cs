﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Collections;

namespace Projecto_c_charp_colégio
{
    public partial class Dados_do_funcionario : Form
    {
        public Dados_do_funcionario()
        {
            InitializeComponent();
        }

        private void Dados_do_funcionario_Load(object sender, EventArgs e)
        {



            for (int i = 0; i < Dados.nomes.Count; i++)
            {
                txt_nome.Text = Dados.nomes[i].ToString();
                txt_telefone.Text =  Dados.telefones[i].ToString();
                txt_idade.Text = Dados.idades[i].ToString();
                txt_salario.Text = Dados.salarioDiario[i].ToString()+" KZ";
                
            }
             
        }

        private void panel3_Paint(object sender, PaintEventArgs e)
        {

        }
    }
}
