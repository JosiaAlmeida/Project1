﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Projecto_c_charp_colégio
{
    public partial class ConsultarCandidato : Form
    {
        public ConsultarCandidato()
        {
            InitializeComponent();
        }

       

        private void verificar(string numero)
        {
            int c = 0,verif=0,anular=0;
            for(int i = 0; i < Dados_Cadidatos.nomes.Count; i++)
            {
                if (Dados_Cadidatos.nomes[i].ToString() != "")
                {
                    if (Dados_Cadidatos.NumeroInscricao[i].ToString() == numero)
                    {
                        c = 1;
                        verif = c;
                        Dados_Cadidatos.pos = i;
                        anular = 0;
                    }
                    else
                    {
                        c = 0;
                    }
                }
                else
                {
                    anular = 1;
                }
                
            }
            if (verif == 1 && anular==0)
            {

                if (anular == 0)
                {
                    MessageBox.Show("Candidato encontrado ");



                    Consultar_candidato_mostrar consultar_Candidato_Mostrar = new Consultar_candidato_mostrar();
                    consultar_Candidato_Mostrar.Show();
                }
                



            }
            else if (verif == 0 || c == 0)
            {
                if (anular == 1)
                {
                    MessageBox.Show("Candidato não encontrado", "Informação ", MessageBoxButtons.OK, MessageBoxIcon.Information);
                }
            }
        }
 

        private void ConsultarCandidato_Load(object sender, EventArgs e)
        {

        }

        private void btn_consultar_Click_1(object sender, EventArgs e)
        {

            string numero = num_consultar.Value.ToString();

            verificar(numero);
        }
    }
}
