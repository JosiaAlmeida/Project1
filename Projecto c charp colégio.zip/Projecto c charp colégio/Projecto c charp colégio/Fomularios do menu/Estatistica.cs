﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Projecto_c_charp_colégio
{
    public partial class Estatistica : Form
    {
        public Estatistica()
        {
            InitializeComponent();
        }

        private void Estatistica_Load(object sender, EventArgs e)
        {
            verificar();
        }

        private void verificar()

        {
            int M = 0, F = 0,c=0,count=0;
            double perc_M = 0, perc_H = 0;
            for (int i = 0; i < Dados_Cadidatos.sexo.Count; i++)
            {
                if (Dados_Cadidatos.nomes[i].ToString() == "")
                {

                 
                }
                else
                {
                    if (Dados_Cadidatos.sexo[i].ToString() == "Masculino")
                    {
                        M++;
                    }
                     if (Dados_Cadidatos.sexo[i].ToString() == "Feminino")
                    {
                        F++;
                    }
                     
                      

                    
                    c++;
                   
                   
                }
                 
            }

            perc_M = F * 100 / c;
            perc_H = M * 100 / c;
            

            lb_homens.Text = M.ToString();
            lb_mulheres.Text = F.ToString();
 
            pb_mulheres.Value=int.Parse(perc_M.ToString());
            pb_homens.Value = int.Parse(perc_H.ToString());

        }

        private void panel3_Paint(object sender, PaintEventArgs e)
        {

        }
    }
}
