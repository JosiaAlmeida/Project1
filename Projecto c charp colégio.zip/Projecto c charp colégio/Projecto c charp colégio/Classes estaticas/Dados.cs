﻿using System;
using System.Collections;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Projecto_c_charp_colégio
{
    static class Dados
    {
       public static  ArrayList nomes = new ArrayList();
       public  static ArrayList telefones = new ArrayList();
       public static ArrayList idades = new ArrayList();
       public static ArrayList salarioDiario = new ArrayList();
       public static ArrayList codigo=new ArrayList();
    }
}
