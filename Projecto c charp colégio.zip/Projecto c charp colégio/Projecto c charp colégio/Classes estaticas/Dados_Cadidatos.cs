﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Collections;
namespace Projecto_c_charp_colégio
{
    static class Dados_Cadidatos
    {
       public static  ArrayList nomes = new ArrayList();
        public static ArrayList cursos = new ArrayList();
        public static ArrayList sexo = new ArrayList();
        public static ArrayList BI = new ArrayList();
        public static ArrayList idades = new ArrayList();
        public static ArrayList NumeroInscricao = new ArrayList();
        public static int pos;
        public static int mostrar=1;
        public static int atual=0;
        public static bool status=false;
    }
}
