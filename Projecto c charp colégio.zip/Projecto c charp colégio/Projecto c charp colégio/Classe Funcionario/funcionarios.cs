﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Collections;
using System.Windows.Forms;

namespace Projecto_c_charp_colégio
{
    class funcionarios
    {
        private string nome { get; set; }
        private string telefone { get; set; }
        private string idade { get; set; }
        private string salarioDiario { get; set; }
        int idades;
        double salario;

        public funcionarios(string nome, string telefone, string idade, string salarioDiario)
        {
            this.nome = nome;
            this.telefone = telefone;
            this.idade = idade;
            this.salarioDiario = salarioDiario;

            ler();
        }
        private void ler()
        {
             idades=0;
             salario=0;

            excepcoes();
 
            if (idades >= 18 && idades <= 50 && salario >= 5000 && salario <= 10000)
            {

                Dados.nomes.Add(this.nome);
                Dados.telefones.Add(this.telefone);
                Dados.idades.Add(this.idade);
                Dados.salarioDiario.Add(this.salarioDiario);
                verificar01();
            }
            if(idades < 18 || idades > 50)
            {
                MessageBox.Show("A idade não está no intervalo de 18 a 50 anos","Informação",MessageBoxButtons.OK,MessageBoxIcon.Information);
            }
            if (salario<5000 || salario>10000)
            {
                 MessageBox.Show("O salário não está nos intervalos de 5000 a 10000 anos", "Informação", MessageBoxButtons.OK, MessageBoxIcon.Information);

            }
 
        }

        private void verificar01()
        {
           if(MessageBox.Show("Dejas ver os teus dados","Confirmação", MessageBoxButtons.YesNo, MessageBoxIcon.Information)==DialogResult.Yes){
                 Dados_do_funcionario dados_Do_Funcionario = new Dados_do_funcionario();
                dados_Do_Funcionario.Show();
            }
            else
            {
                Principal principal = new Principal();
                principal.Show();
            }    
        }

        private void excepcoes()
        {
            try
            {
                idades = int.Parse(this.idade);
            }
            catch (Exception e)
            {
                MessageBox.Show("Erro não digite caracter neste campo");
            }
            try
            {
                salario = double.Parse(this.salarioDiario);
            }
            catch (Exception e)
            {
                MessageBox.Show("Erro não digite caracter neste campo");
            }


        }
        //private int geradorCodigo()
        //{
        //    int id = 1;
        //    Random a = new Random();
        //    id = a.Next(1000, 9999);
        //    return id;

        //}



    }
}
