﻿namespace Projecto_c_charp_colégio
{
    partial class Principal
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(Principal));
            this.panel3 = new System.Windows.Forms.Panel();
            this.btn_integrantes = new MaterialSkin.Controls.MaterialRaisedButton();
            this.btn_estatistica = new MaterialSkin.Controls.MaterialRaisedButton();
            this.btn_atualizar = new MaterialSkin.Controls.MaterialRaisedButton();
            this.btn_eliminar = new MaterialSkin.Controls.MaterialRaisedButton();
            this.btn_listar = new MaterialSkin.Controls.MaterialRaisedButton();
            this.btn_consultar = new MaterialSkin.Controls.MaterialRaisedButton();
            this.btn_inscrever = new MaterialSkin.Controls.MaterialRaisedButton();
            this.panel1 = new System.Windows.Forms.Panel();
            this.label11 = new System.Windows.Forms.Label();
            this.panel2 = new System.Windows.Forms.Panel();
            this.panel3.SuspendLayout();
            this.panel1.SuspendLayout();
            this.SuspendLayout();
            // 
            // panel3
            // 
            this.panel3.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(64)))), ((int)(((byte)(64)))), ((int)(((byte)(64)))));
            this.panel3.Controls.Add(this.btn_integrantes);
            this.panel3.Controls.Add(this.btn_estatistica);
            this.panel3.Controls.Add(this.btn_atualizar);
            this.panel3.Controls.Add(this.btn_eliminar);
            this.panel3.Controls.Add(this.btn_listar);
            this.panel3.Controls.Add(this.btn_consultar);
            this.panel3.Controls.Add(this.btn_inscrever);
            this.panel3.Location = new System.Drawing.Point(1, 140);
            this.panel3.Name = "panel3";
            this.panel3.Size = new System.Drawing.Size(344, 375);
            this.panel3.TabIndex = 16;
            this.panel3.Paint += new System.Windows.Forms.PaintEventHandler(this.panel3_Paint);
            // 
            // btn_integrantes
            // 
            this.btn_integrantes.Depth = 0;
            this.btn_integrantes.Font = new System.Drawing.Font("Microsoft Sans Serif", 14.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btn_integrantes.Location = new System.Drawing.Point(0, 302);
            this.btn_integrantes.MouseState = MaterialSkin.MouseState.HOVER;
            this.btn_integrantes.Name = "btn_integrantes";
            this.btn_integrantes.Primary = true;
            this.btn_integrantes.Size = new System.Drawing.Size(341, 34);
            this.btn_integrantes.TabIndex = 31;
            this.btn_integrantes.Text = "7-Integrantes do Grupo";
            this.btn_integrantes.UseVisualStyleBackColor = true;
            this.btn_integrantes.Click += new System.EventHandler(this.btn_integrantes_Click);
            // 
            // btn_estatistica
            // 
            this.btn_estatistica.Depth = 0;
            this.btn_estatistica.Font = new System.Drawing.Font("Microsoft Sans Serif", 14.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btn_estatistica.Location = new System.Drawing.Point(0, 258);
            this.btn_estatistica.MouseState = MaterialSkin.MouseState.HOVER;
            this.btn_estatistica.Name = "btn_estatistica";
            this.btn_estatistica.Primary = true;
            this.btn_estatistica.Size = new System.Drawing.Size(341, 34);
            this.btn_estatistica.TabIndex = 30;
            this.btn_estatistica.Text = "6-Estátistica";
            this.btn_estatistica.UseVisualStyleBackColor = true;
            this.btn_estatistica.Click += new System.EventHandler(this.btn_estatistica_Click);
            // 
            // btn_atualizar
            // 
            this.btn_atualizar.Depth = 0;
            this.btn_atualizar.Font = new System.Drawing.Font("Microsoft Sans Serif", 14.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btn_atualizar.Location = new System.Drawing.Point(0, 213);
            this.btn_atualizar.MouseState = MaterialSkin.MouseState.HOVER;
            this.btn_atualizar.Name = "btn_atualizar";
            this.btn_atualizar.Primary = true;
            this.btn_atualizar.Size = new System.Drawing.Size(341, 34);
            this.btn_atualizar.TabIndex = 29;
            this.btn_atualizar.Text = "5-Atualizar Candidato";
            this.btn_atualizar.UseVisualStyleBackColor = true;
            this.btn_atualizar.Click += new System.EventHandler(this.btn_atualizar_Click);
            // 
            // btn_eliminar
            // 
            this.btn_eliminar.Depth = 0;
            this.btn_eliminar.Font = new System.Drawing.Font("Microsoft Sans Serif", 14.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btn_eliminar.Location = new System.Drawing.Point(0, 171);
            this.btn_eliminar.MouseState = MaterialSkin.MouseState.HOVER;
            this.btn_eliminar.Name = "btn_eliminar";
            this.btn_eliminar.Primary = true;
            this.btn_eliminar.Size = new System.Drawing.Size(341, 34);
            this.btn_eliminar.TabIndex = 28;
            this.btn_eliminar.Text = "4-Eliminar Candidato";
            this.btn_eliminar.UseVisualStyleBackColor = true;
            this.btn_eliminar.Click += new System.EventHandler(this.btn_eliminar_Click);
            // 
            // btn_listar
            // 
            this.btn_listar.Depth = 0;
            this.btn_listar.Font = new System.Drawing.Font("Microsoft Sans Serif", 14.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btn_listar.Location = new System.Drawing.Point(0, 127);
            this.btn_listar.MouseState = MaterialSkin.MouseState.HOVER;
            this.btn_listar.Name = "btn_listar";
            this.btn_listar.Primary = true;
            this.btn_listar.Size = new System.Drawing.Size(341, 34);
            this.btn_listar.TabIndex = 27;
            this.btn_listar.Text = "3-Listar Candidatos";
            this.btn_listar.UseVisualStyleBackColor = true;
            this.btn_listar.Click += new System.EventHandler(this.btn_listar_Click);
            // 
            // btn_consultar
            // 
            this.btn_consultar.Depth = 0;
            this.btn_consultar.Font = new System.Drawing.Font("Microsoft Sans Serif", 14.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btn_consultar.Location = new System.Drawing.Point(-1, 83);
            this.btn_consultar.MouseState = MaterialSkin.MouseState.HOVER;
            this.btn_consultar.Name = "btn_consultar";
            this.btn_consultar.Primary = true;
            this.btn_consultar.Size = new System.Drawing.Size(341, 34);
            this.btn_consultar.TabIndex = 26;
            this.btn_consultar.Text = "2-Consultar Candidato";
            this.btn_consultar.UseVisualStyleBackColor = true;
            this.btn_consultar.Click += new System.EventHandler(this.btn_consultar_Click_1);
            // 
            // btn_inscrever
            // 
            this.btn_inscrever.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(64)))), ((int)(((byte)(70)))), ((int)(((byte)(64)))));
            this.btn_inscrever.Depth = 0;
            this.btn_inscrever.Font = new System.Drawing.Font("Microsoft Sans Serif", 14.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btn_inscrever.Location = new System.Drawing.Point(0, 41);
            this.btn_inscrever.MouseState = MaterialSkin.MouseState.HOVER;
            this.btn_inscrever.Name = "btn_inscrever";
            this.btn_inscrever.Primary = true;
            this.btn_inscrever.Size = new System.Drawing.Size(341, 34);
            this.btn_inscrever.TabIndex = 25;
            this.btn_inscrever.Text = "1-Inscrever Candidato";
            this.btn_inscrever.UseVisualStyleBackColor = false;
            this.btn_inscrever.Click += new System.EventHandler(this.btn_inscrever_Click_1);
            // 
            // panel1
            // 
            this.panel1.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(0)))), ((int)(((byte)(30)))));
            this.panel1.Controls.Add(this.label11);
            this.panel1.Controls.Add(this.panel2);
            this.panel1.Location = new System.Drawing.Point(1, 0);
            this.panel1.Name = "panel1";
            this.panel1.Size = new System.Drawing.Size(344, 330);
            this.panel1.TabIndex = 15;
            // 
            // label11
            // 
            this.label11.AutoSize = true;
            this.label11.Font = new System.Drawing.Font("Candara", 15.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label11.ForeColor = System.Drawing.Color.White;
            this.label11.Location = new System.Drawing.Point(144, 64);
            this.label11.Name = "label11";
            this.label11.Size = new System.Drawing.Size(172, 26);
            this.label11.TabIndex = 2;
            this.label11.Text = "MENU PRINCIPAL";
            // 
            // panel2
            // 
            this.panel2.BackColor = System.Drawing.Color.White;
            this.panel2.BackgroundImage = ((System.Drawing.Image)(resources.GetObject("panel2.BackgroundImage")));
            this.panel2.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.panel2.Location = new System.Drawing.Point(14, 17);
            this.panel2.Name = "panel2";
            this.panel2.Size = new System.Drawing.Size(107, 106);
            this.panel2.TabIndex = 1;
            // 
            // Principal
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(341, 491);
            this.Controls.Add(this.panel3);
            this.Controls.Add(this.panel1);
            this.Icon = ((System.Drawing.Icon)(resources.GetObject("$this.Icon")));
            this.MaximizeBox = false;
            this.Name = "Principal";
            this.Text = "Principal";
            this.Load += new System.EventHandler(this.Principal_Load);
            this.panel3.ResumeLayout(false);
            this.panel1.ResumeLayout(false);
            this.panel1.PerformLayout();
            this.ResumeLayout(false);

        }

        #endregion
        private System.Windows.Forms.Panel panel3;
        private System.Windows.Forms.Panel panel1;
        private System.Windows.Forms.Label label11;
        private System.Windows.Forms.Panel panel2;
        private MaterialSkin.Controls.MaterialRaisedButton btn_integrantes;
        private MaterialSkin.Controls.MaterialRaisedButton btn_estatistica;
        private MaterialSkin.Controls.MaterialRaisedButton btn_atualizar;
        private MaterialSkin.Controls.MaterialRaisedButton btn_eliminar;
        private MaterialSkin.Controls.MaterialRaisedButton btn_listar;
        private MaterialSkin.Controls.MaterialRaisedButton btn_consultar;
        private MaterialSkin.Controls.MaterialRaisedButton btn_inscrever;
    }
}