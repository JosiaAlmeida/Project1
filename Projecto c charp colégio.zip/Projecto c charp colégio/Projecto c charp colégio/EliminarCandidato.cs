﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Projecto_c_charp_colégio
{
    public partial class EliminarCandidato : Form
    {
        int confirm = 0,conf;
        public EliminarCandidato()
        {
            InitializeComponent();
        }

        

        private void btn_eliminar_Click_1(object sender, EventArgs e)
        {
                  verificar();
        }

        private void N_ID_ValueChanged(object sender, EventArgs e)
        {

        }

        private void panel3_Paint(object sender, PaintEventArgs e)
        {

        }

        private void label6_Click(object sender, EventArgs e)
        {

        }

        private void panel1_Paint(object sender, PaintEventArgs e)
        {

        }

        private void label7_Click(object sender, EventArgs e)
        {

        }

        private void panel2_Paint(object sender, PaintEventArgs e)
        {

        }

        private void verificar()
            {
                int c = 0, verif = 0, posicao = 0,count=0;
                int num = int.Parse(N_ID.Value.ToString());
            for (int i = 0; i < Dados_Cadidatos.NumeroInscricao.Count; i++)
            {
                if (Dados_Cadidatos.nomes[i].ToString() != "")
                {
                    if (Dados_Cadidatos.NumeroInscricao[i].ToString() == num.ToString())
                    {
                        c = 1;
                        verif = c;
                        posicao = i;
                        Dados_Cadidatos.pos = i;
                        

                    }
                    else
                    {
                        c = 0;

                    }
                }
                else
                {
                    c = 0;
                     
                }
            }



                if (verif == 1)
                {

                    MessageBox.Show("Candidato encontrado ");

                    Consultar_candidato_mostrar consultar_Candidato_Mostrar = new Consultar_candidato_mostrar();
                    consultar_Candidato_Mostrar.Show();
                    if (MessageBox.Show("Tens certeza que queres eliminar? ", "Informação", MessageBoxButtons.YesNo, MessageBoxIcon.Information) == DialogResult.Yes)
                    {
                        Dados_Cadidatos.nomes[posicao] = "";
                        Dados_Cadidatos.cursos[posicao] = "";
                        Dados_Cadidatos.sexo[posicao] = "";
                        Dados_Cadidatos.BI[posicao] = "";
                        Dados_Cadidatos.idades[posicao] = "";
                        Dados_Cadidatos.mostrar = 0;
                        


                    MessageBox.Show("Eliminado com sucesso", "Informação");
                          

                    }
                    verif = 0;
                }
                else if (verif == 0 || c == 0)
                {
                    MessageBox.Show("Candidato não encontrado", "Informação ", MessageBoxButtons.OK, MessageBoxIcon.Information);
                }



            }
        }
}
