﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Collections;

namespace Projecto_c_charp_colégio
{
    public partial class Form1: Form
    {
        string nomes;
        string idades;
        string telefone;
        string salarioDiario;
        bool verifiq;
        public Form1()
        {
            InitializeComponent();
        }

        private void textBox3_TextChanged(object sender, EventArgs e)
        {

        }

        private void btn_cadastrar_Click(object sender, EventArgs e)
        {
        }

        
        private void verificar()
        {
            for (int i = 0; i < Dados_Cadidatos.nomes.Count; i++)
            {
                Dados_Cadidatos.nomes.Clear();
                Dados_Cadidatos.cursos.Clear();
                Dados_Cadidatos.BI.Clear();
                Dados_Cadidatos.NumeroInscricao.Clear();
                Dados_Cadidatos.idades.Clear();
                Dados_Cadidatos.sexo.Clear();
            }
        }

        private void bunifuGradientPanel1_Paint(object sender, PaintEventArgs e)
        {

        }

        private void btn_cadastrar_Click_1(object sender, EventArgs e)
        {

            nomes = txt_nome.Text;
            idades = txt_idade.Text;
            telefone = txt_telefone.Text;
            salarioDiario = txt_salario.Text;




            if (txt_nome.Text != string.Empty && txt_idade.Text != string.Empty && txt_salario.Text != string.Empty && txt_telefone.Text != string.Empty)
            {
                verificar();
                funcionarios funcionarios = new funcionarios(nomes, telefone, idades, salarioDiario);

            }
            else
            {
                MessageBox.Show("Por favor preencha todos os campos", "Informação", MessageBoxButtons.OK, MessageBoxIcon.Exclamation);
            }


        }
    }
}
