﻿namespace Projecto_c_charp_colégio
{
    partial class Form1
    {
        /// <summary>
        /// Variável de designer necessária.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Limpar os recursos que estão sendo usados.
        /// </summary>
        /// <param name="disposing">true se for necessário descartar os recursos gerenciados; caso contrário, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Código gerado pelo Windows Form Designer

        /// <summary>
        /// Método necessário para suporte ao Designer - não modifique 
        /// o conteúdo deste método com o editor de código.
        /// </summary>
        private void InitializeComponent()
        {
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(Form1));
            this.label4 = new System.Windows.Forms.Label();
            this.panel1 = new System.Windows.Forms.Panel();
            this.panel2 = new System.Windows.Forms.Panel();
            this.bunifuCustomLabel1 = new Bunifu.Framework.UI.BunifuCustomLabel();
            this.bunifuGradientPanel1 = new Bunifu.Framework.UI.BunifuGradientPanel();
            this.txt_nome = new Bunifu.Framework.UI.BunifuMaterialTextbox();
            this.txt_telefone = new Bunifu.Framework.UI.BunifuMaterialTextbox();
            this.txt_idade = new Bunifu.Framework.UI.BunifuMaterialTextbox();
            this.txt_salario = new Bunifu.Framework.UI.BunifuMaterialTextbox();
            this.label3 = new System.Windows.Forms.Label();
            this.label2 = new System.Windows.Forms.Label();
            this.label1 = new System.Windows.Forms.Label();
            this.btn_cadastrar = new MaterialSkin.Controls.MaterialRaisedButton();
            this.panel2.SuspendLayout();
            this.bunifuGradientPanel1.SuspendLayout();
            this.SuspendLayout();
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.Font = new System.Drawing.Font("Lucida Sans Unicode", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label4.Location = new System.Drawing.Point(44, 209);
            this.label4.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(111, 16);
            this.label4.TabIndex = 6;
            this.label4.Text = "SALARIO DIARIO";
            // 
            // panel1
            // 
            this.panel1.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(224)))), ((int)(((byte)(224)))), ((int)(((byte)(224)))));
            this.panel1.BackgroundImage = ((System.Drawing.Image)(resources.GetObject("panel1.BackgroundImage")));
            this.panel1.Location = new System.Drawing.Point(107, 69);
            this.panel1.Name = "panel1";
            this.panel1.Size = new System.Drawing.Size(373, 126);
            this.panel1.TabIndex = 9;
            // 
            // panel2
            // 
            this.panel2.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(0)))), ((int)(((byte)(30)))));
            this.panel2.Controls.Add(this.bunifuCustomLabel1);
            this.panel2.Location = new System.Drawing.Point(60, 230);
            this.panel2.Name = "panel2";
            this.panel2.Size = new System.Drawing.Size(483, 59);
            this.panel2.TabIndex = 10;
            // 
            // bunifuCustomLabel1
            // 
            this.bunifuCustomLabel1.AutoSize = true;
            this.bunifuCustomLabel1.Font = new System.Drawing.Font("Cambria", 15.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.bunifuCustomLabel1.ForeColor = System.Drawing.Color.White;
            this.bunifuCustomLabel1.Location = new System.Drawing.Point(107, 20);
            this.bunifuCustomLabel1.Name = "bunifuCustomLabel1";
            this.bunifuCustomLabel1.Size = new System.Drawing.Size(299, 25);
            this.bunifuCustomLabel1.TabIndex = 0;
            this.bunifuCustomLabel1.Text = "CADASTRO DE  FUNCIONARIO";
            // 
            // bunifuGradientPanel1
            // 
            this.bunifuGradientPanel1.BackColor = System.Drawing.Color.White;
            this.bunifuGradientPanel1.BackgroundImage = ((System.Drawing.Image)(resources.GetObject("bunifuGradientPanel1.BackgroundImage")));
            this.bunifuGradientPanel1.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.bunifuGradientPanel1.Controls.Add(this.btn_cadastrar);
            this.bunifuGradientPanel1.Controls.Add(this.label1);
            this.bunifuGradientPanel1.Controls.Add(this.label2);
            this.bunifuGradientPanel1.Controls.Add(this.label3);
            this.bunifuGradientPanel1.Controls.Add(this.txt_salario);
            this.bunifuGradientPanel1.Controls.Add(this.txt_idade);
            this.bunifuGradientPanel1.Controls.Add(this.txt_telefone);
            this.bunifuGradientPanel1.Controls.Add(this.txt_nome);
            this.bunifuGradientPanel1.Controls.Add(this.label4);
            this.bunifuGradientPanel1.GradientBottomLeft = System.Drawing.Color.White;
            this.bunifuGradientPanel1.GradientBottomRight = System.Drawing.Color.White;
            this.bunifuGradientPanel1.GradientTopLeft = System.Drawing.Color.White;
            this.bunifuGradientPanel1.GradientTopRight = System.Drawing.Color.White;
            this.bunifuGradientPanel1.Location = new System.Drawing.Point(60, 271);
            this.bunifuGradientPanel1.Name = "bunifuGradientPanel1";
            this.bunifuGradientPanel1.Quality = 10;
            this.bunifuGradientPanel1.Size = new System.Drawing.Size(483, 312);
            this.bunifuGradientPanel1.TabIndex = 11;
            this.bunifuGradientPanel1.Paint += new System.Windows.Forms.PaintEventHandler(this.bunifuGradientPanel1_Paint);
            // 
            // txt_nome
            // 
            this.txt_nome.Cursor = System.Windows.Forms.Cursors.IBeam;
            this.txt_nome.Font = new System.Drawing.Font("Century Gothic", 9.75F);
            this.txt_nome.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(64)))), ((int)(((byte)(64)))), ((int)(((byte)(64)))));
            this.txt_nome.HintForeColor = System.Drawing.Color.Empty;
            this.txt_nome.HintText = "";
            this.txt_nome.isPassword = false;
            this.txt_nome.LineFocusedColor = System.Drawing.Color.Blue;
            this.txt_nome.LineIdleColor = System.Drawing.Color.Gray;
            this.txt_nome.LineMouseHoverColor = System.Drawing.Color.Blue;
            this.txt_nome.LineThickness = 3;
            this.txt_nome.Location = new System.Drawing.Point(163, 55);
            this.txt_nome.Margin = new System.Windows.Forms.Padding(4);
            this.txt_nome.Name = "txt_nome";
            this.txt_nome.Size = new System.Drawing.Size(200, 33);
            this.txt_nome.TabIndex = 8;
            this.txt_nome.TextAlign = System.Windows.Forms.HorizontalAlignment.Left;
            // 
            // txt_telefone
            // 
            this.txt_telefone.Cursor = System.Windows.Forms.Cursors.IBeam;
            this.txt_telefone.Font = new System.Drawing.Font("Century Gothic", 9.75F);
            this.txt_telefone.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(64)))), ((int)(((byte)(64)))), ((int)(((byte)(64)))));
            this.txt_telefone.HintForeColor = System.Drawing.Color.Empty;
            this.txt_telefone.HintText = "";
            this.txt_telefone.isPassword = false;
            this.txt_telefone.LineFocusedColor = System.Drawing.Color.Blue;
            this.txt_telefone.LineIdleColor = System.Drawing.Color.Gray;
            this.txt_telefone.LineMouseHoverColor = System.Drawing.Color.Blue;
            this.txt_telefone.LineThickness = 3;
            this.txt_telefone.Location = new System.Drawing.Point(163, 100);
            this.txt_telefone.Margin = new System.Windows.Forms.Padding(4);
            this.txt_telefone.Name = "txt_telefone";
            this.txt_telefone.Size = new System.Drawing.Size(200, 33);
            this.txt_telefone.TabIndex = 9;
            this.txt_telefone.TextAlign = System.Windows.Forms.HorizontalAlignment.Left;
            // 
            // txt_idade
            // 
            this.txt_idade.Cursor = System.Windows.Forms.Cursors.IBeam;
            this.txt_idade.Font = new System.Drawing.Font("Century Gothic", 9.75F);
            this.txt_idade.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(64)))), ((int)(((byte)(64)))), ((int)(((byte)(64)))));
            this.txt_idade.HintForeColor = System.Drawing.Color.Empty;
            this.txt_idade.HintText = "";
            this.txt_idade.isPassword = false;
            this.txt_idade.LineFocusedColor = System.Drawing.Color.Blue;
            this.txt_idade.LineIdleColor = System.Drawing.Color.Gray;
            this.txt_idade.LineMouseHoverColor = System.Drawing.Color.Blue;
            this.txt_idade.LineThickness = 3;
            this.txt_idade.Location = new System.Drawing.Point(163, 150);
            this.txt_idade.Margin = new System.Windows.Forms.Padding(4);
            this.txt_idade.Name = "txt_idade";
            this.txt_idade.Size = new System.Drawing.Size(200, 33);
            this.txt_idade.TabIndex = 10;
            this.txt_idade.TextAlign = System.Windows.Forms.HorizontalAlignment.Left;
            // 
            // txt_salario
            // 
            this.txt_salario.Cursor = System.Windows.Forms.Cursors.IBeam;
            this.txt_salario.Font = new System.Drawing.Font("Century Gothic", 9.75F);
            this.txt_salario.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(64)))), ((int)(((byte)(64)))), ((int)(((byte)(64)))));
            this.txt_salario.HintForeColor = System.Drawing.Color.Empty;
            this.txt_salario.HintText = "";
            this.txt_salario.isPassword = false;
            this.txt_salario.LineFocusedColor = System.Drawing.Color.Blue;
            this.txt_salario.LineIdleColor = System.Drawing.Color.Gray;
            this.txt_salario.LineMouseHoverColor = System.Drawing.Color.Blue;
            this.txt_salario.LineThickness = 3;
            this.txt_salario.Location = new System.Drawing.Point(163, 191);
            this.txt_salario.Margin = new System.Windows.Forms.Padding(4);
            this.txt_salario.Name = "txt_salario";
            this.txt_salario.Size = new System.Drawing.Size(200, 33);
            this.txt_salario.TabIndex = 11;
            this.txt_salario.TextAlign = System.Windows.Forms.HorizontalAlignment.Left;
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Font = new System.Drawing.Font("Lucida Sans Unicode", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label3.Location = new System.Drawing.Point(107, 167);
            this.label3.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(48, 16);
            this.label3.TabIndex = 12;
            this.label3.Text = "IDADE";
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Font = new System.Drawing.Font("Lucida Sans Unicode", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label2.Location = new System.Drawing.Point(84, 117);
            this.label2.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(71, 16);
            this.label2.TabIndex = 13;
            this.label2.Text = "TELEFONE";
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Font = new System.Drawing.Font("Lucida Sans Unicode", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label1.Location = new System.Drawing.Point(109, 72);
            this.label1.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(46, 16);
            this.label1.TabIndex = 14;
            this.label1.Text = "NOME";
            // 
            // btn_cadastrar
            // 
            this.btn_cadastrar.Depth = 0;
            this.btn_cadastrar.Location = new System.Drawing.Point(329, 261);
            this.btn_cadastrar.MouseState = MaterialSkin.MouseState.HOVER;
            this.btn_cadastrar.Name = "btn_cadastrar";
            this.btn_cadastrar.Primary = true;
            this.btn_cadastrar.Size = new System.Drawing.Size(125, 34);
            this.btn_cadastrar.TabIndex = 15;
            this.btn_cadastrar.Text = "Cadastrar";
            this.btn_cadastrar.UseVisualStyleBackColor = true;
            this.btn_cadastrar.Click += new System.EventHandler(this.btn_cadastrar_Click_1);
            // 
            // Form1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(8F, 19F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(64)))), ((int)(((byte)(64)))), ((int)(((byte)(62)))));
            this.ClientSize = new System.Drawing.Size(605, 629);
            this.Controls.Add(this.panel2);
            this.Controls.Add(this.bunifuGradientPanel1);
            this.Controls.Add(this.panel1);
            this.Font = new System.Drawing.Font("Segoe MDL2 Assets", 14.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.Icon = ((System.Drawing.Icon)(resources.GetObject("$this.Icon")));
            this.Margin = new System.Windows.Forms.Padding(4);
            this.MaximizeBox = false;
            this.Name = "Form1";
            this.Text = "Cadastro";
            this.panel2.ResumeLayout(false);
            this.panel2.PerformLayout();
            this.bunifuGradientPanel1.ResumeLayout(false);
            this.bunifuGradientPanel1.PerformLayout();
            this.ResumeLayout(false);

        }

        #endregion
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.Panel panel1;
        private System.Windows.Forms.Panel panel2;
        private Bunifu.Framework.UI.BunifuCustomLabel bunifuCustomLabel1;
        private Bunifu.Framework.UI.BunifuGradientPanel bunifuGradientPanel1;
        private Bunifu.Framework.UI.BunifuMaterialTextbox txt_nome;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.Label label3;
        private Bunifu.Framework.UI.BunifuMaterialTextbox txt_salario;
        private Bunifu.Framework.UI.BunifuMaterialTextbox txt_idade;
        private Bunifu.Framework.UI.BunifuMaterialTextbox txt_telefone;
        private MaterialSkin.Controls.MaterialRaisedButton btn_cadastrar;
    }
}

