﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Projecto_c_charp_colégio
{
    public partial class Principal : Form
    {
        int mostra = 0;
        
        
        public Principal()
        {
            InitializeComponent();
        }

       

  
        

        private void Principal_Load(object sender, EventArgs e)
        {
              
        }
        private void mensagem()
        {
            MessageBox.Show("Inscreva candidato para acessar outrar funcionalidades", "Informação", MessageBoxButtons.OK, MessageBoxIcon.Information);

        }

        private bool validar()
        {
            for (int i = 0; i < Dados_Cadidatos.nomes.Count; i++)
            {
                if (Dados_Cadidatos.mostrar != 0)
                {
                    if (Dados_Cadidatos.nomes[i].ToString() == "")
                    {
                        mostra = Dados_Cadidatos.mostrar;

                    }
                    if (Dados_Cadidatos.nomes[i].ToString() != "")
                    {
                        Dados_Cadidatos.mostrar = 1;
                        mostra = Dados_Cadidatos.mostrar;



                    }
                }
                else if (Dados_Cadidatos.mostrar == 0)
                {
                    if (Dados_Cadidatos.nomes[i].ToString() == "")
                    {
                        mostra = Dados_Cadidatos.mostrar;
                         
                    }
                    if (Dados_Cadidatos.nomes[i].ToString() != "")
                    {
                        Dados_Cadidatos.mostrar = 1;
                        mostra = Dados_Cadidatos.mostrar;
                      
 
                      
                    }

                }



            }
            if (mostra == 1)
            {
                return true;


            }
            else if (mostra == 0)
            {
                return false;
            }
            else
            {
                return false;
            }

        }

        private void panel3_Paint(object sender, PaintEventArgs e)
        {

        }

        private void btn_inscrever_Click_1(object sender, EventArgs e)
        {

            Inscrever inscrever = new Inscrever();
            inscrever.Show();
        }

        private void btn_consultar_Click_1(object sender, EventArgs e)
        {
            if (validar() == true)
            {
                ConsultarCandidato consultarCandidato = new ConsultarCandidato();
                consultarCandidato.Show();

            }
            else if (validar() == false)
            {
                mensagem();
            }
        }

        private void btn_listar_Click(object sender, EventArgs e)
        {

            if (validar() == true)
            {
                ListarCandidatos listarCandidatos = new ListarCandidatos();
                listarCandidatos.Show();

            }
            else if (validar() == false)
            {
                mensagem();
            }
        }

        private void btn_integrantes_Click(object sender, EventArgs e)
        {
            IntegrantesDoGrupo integrantesDoGrupo = new IntegrantesDoGrupo();
            integrantesDoGrupo.Show();
        }

        private void btn_estatistica_Click(object sender, EventArgs e)
        {

            if (validar() == true)
            {
                Estatistica estatistica = new Estatistica();
                estatistica.Show();

            }
            else if (validar() == false)
            {
                mensagem();

            }
        }

        private void btn_eliminar_Click(object sender, EventArgs e)
        {

            if (validar() == true)
            {
                EliminarCandidato eliminarCandidato = new EliminarCandidato();
                eliminarCandidato.Show();

            }
            else if (validar() == false)
            {
                mensagem();
            }
        }

        private void btn_atualizar_Click(object sender, EventArgs e)
        {
            if (validar() == true)
            {
                AtualizarCandidato atualizarCandidato = new AtualizarCandidato();
                atualizarCandidato.Show();
            }
            else if (validar() == false)
            {
                mensagem();

            }
        }
    }
}
