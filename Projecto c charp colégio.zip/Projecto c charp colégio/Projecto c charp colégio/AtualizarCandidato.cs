﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Projecto_c_charp_colégio
{
    public partial class AtualizarCandidato : Form
    {
        int posicao = 0;
        public AtualizarCandidato()
        {
            InitializeComponent();
        }

        
        private void verificar()
        {
            int c = 0, verif = 0,anular=0;
            int num = int.Parse(N_ID.Value.ToString());
            for (int i = 0; i < Dados_Cadidatos.NumeroInscricao.Count; i++)
            {
                if (Dados_Cadidatos.nomes[i].ToString() != "")
                {
                    if (Dados_Cadidatos.NumeroInscricao[i].ToString() == num.ToString())
                    {
                        c = 1;
                        verif = c;
                        posicao = i;
                        Dados_Cadidatos.pos = i;
                        Dados_Cadidatos.atual = 1;

                    }
                    else
                    {
                        c = 0;
                    }
                }
                else
                {
                    anular = 1;
                }
            }



            if (verif == 1)
            {
                if (anular == 0 && Dados_Cadidatos.atual==1)
                {
                    MessageBox.Show("Candidato encontrado ");

                    Consultar_candidato_mostrar consultar_Candidato_Mostrar = new Consultar_candidato_mostrar();

                    if (MessageBox.Show("Tens certeza que queres Atualizar? ", "Informação", MessageBoxButtons.YesNo, MessageBoxIcon.Information) == DialogResult.Yes)
                    {

                        atualizar();
                        MessageBox.Show("Atualizado com sucesso", "Informação");
                        consultar_Candidato_Mostrar.Show();
                        Dados_Cadidatos.atual = 0;
                         
                    }
                }


            }

            else if (verif == 0 || c == 0)
            {
                if (Dados_Cadidatos.atual==0)
                {
                    MessageBox.Show("Candidato não encontrado", "Informação ", MessageBoxButtons.OK, MessageBoxIcon.Information);

                }

            }
            


        }
        private void atualizar()
        {
            if (txt_nome.Text != "")
            {
                Dados_Cadidatos.nomes[posicao] = txt_nome.Text;
            }
           
            if (txt_idade.Text !="")
            { 
                Dados_Cadidatos.idades[posicao] = txt_idade.Text;
            }
            if (cmb_cursos.Text !="")
            {
                Dados_Cadidatos.cursos[posicao] = cmb_cursos.Text;
            }

        }
         
        private void bunifuMaterialTextbox2_OnValueChanged(object sender, EventArgs e)
        {

        }

        private void btn_atualizar_Click(object sender, EventArgs e)
        {
            int verific = int.Parse(txt_idade.Text);
            if (verific >= 12 && verific <= 20)
            {
                verificar();
            }
            else
            {
                MessageBox.Show("A sua idade não está no intervalo de 12 a 20 anos", "Informação ", MessageBoxButtons.OK, MessageBoxIcon.Information);

            }
        }
    }
}
