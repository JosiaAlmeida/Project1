﻿namespace Projecto_c_charp_colégio
{
    partial class AtualizarCandidato
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(AtualizarCandidato));
            this.label1 = new System.Windows.Forms.Label();
            this.N_ID = new System.Windows.Forms.NumericUpDown();
            this.cmb_cursos = new System.Windows.Forms.ComboBox();
            this.btn_atualizar = new MaterialSkin.Controls.MaterialRaisedButton();
            this.txt_idade = new Bunifu.Framework.UI.BunifuMaterialTextbox();
            this.label14 = new System.Windows.Forms.Label();
            this.txt_nome = new Bunifu.Framework.UI.BunifuMaterialTextbox();
            this.label11 = new System.Windows.Forms.Label();
            this.panel2 = new System.Windows.Forms.Panel();
            this.panel1 = new System.Windows.Forms.Panel();
            this.label10 = new System.Windows.Forms.Label();
            this.panel3 = new System.Windows.Forms.Panel();
            this.label4 = new System.Windows.Forms.Label();
            this.label5 = new System.Windows.Forms.Label();
            ((System.ComponentModel.ISupportInitialize)(this.N_ID)).BeginInit();
            this.panel1.SuspendLayout();
            this.panel3.SuspendLayout();
            this.SuspendLayout();
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Font = new System.Drawing.Font("Yu Gothic UI", 15.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label1.Location = new System.Drawing.Point(633, 20);
            this.label1.Margin = new System.Windows.Forms.Padding(6, 0, 6, 0);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(196, 30);
            this.label1.TabIndex = 0;
            this.label1.Text = "Atualizar Candidato";
            // 
            // N_ID
            // 
            this.N_ID.Location = new System.Drawing.Point(168, 32);
            this.N_ID.Margin = new System.Windows.Forms.Padding(6);
            this.N_ID.Name = "N_ID";
            this.N_ID.Size = new System.Drawing.Size(47, 33);
            this.N_ID.TabIndex = 2;
            this.N_ID.Value = new decimal(new int[] {
            1,
            0,
            0,
            0});
            // 
            // cmb_cursos
            // 
            this.cmb_cursos.FormattingEnabled = true;
            this.cmb_cursos.Items.AddRange(new object[] {
            "Técnico de Informática",
            "Técnico de Gestão do Sistemas Informáticos",
            "Técnico de Electronica e Telecomunicações",
            "Técnico de Obras",
            "Técnico de Frio e Climatização",
            "Técnico de Bioquímica",
            "Técnico de Química Industrial",
            "Técnico de Máquinas e Motores",
            "Técnico de Metalomecânica",
            "Técnico de Desenhador Projetista"});
            this.cmb_cursos.Location = new System.Drawing.Point(118, 130);
            this.cmb_cursos.Name = "cmb_cursos";
            this.cmb_cursos.Size = new System.Drawing.Size(248, 33);
            this.cmb_cursos.TabIndex = 21;
            // 
            // btn_atualizar
            // 
            this.btn_atualizar.Depth = 0;
            this.btn_atualizar.Location = new System.Drawing.Point(230, 251);
            this.btn_atualizar.MouseState = MaterialSkin.MouseState.HOVER;
            this.btn_atualizar.Name = "btn_atualizar";
            this.btn_atualizar.Primary = true;
            this.btn_atualizar.Size = new System.Drawing.Size(125, 34);
            this.btn_atualizar.TabIndex = 24;
            this.btn_atualizar.Text = "ATUALIZAR";
            this.btn_atualizar.UseVisualStyleBackColor = true;
            this.btn_atualizar.Click += new System.EventHandler(this.btn_atualizar_Click);
            // 
            // txt_idade
            // 
            this.txt_idade.BackColor = System.Drawing.Color.White;
            this.txt_idade.Cursor = System.Windows.Forms.Cursors.IBeam;
            this.txt_idade.Font = new System.Drawing.Font("Century Gothic", 9.75F);
            this.txt_idade.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(64)))), ((int)(((byte)(64)))), ((int)(((byte)(64)))));
            this.txt_idade.HintForeColor = System.Drawing.Color.Empty;
            this.txt_idade.HintText = "";
            this.txt_idade.isPassword = false;
            this.txt_idade.LineFocusedColor = System.Drawing.Color.Blue;
            this.txt_idade.LineIdleColor = System.Drawing.Color.Gray;
            this.txt_idade.LineMouseHoverColor = System.Drawing.Color.Blue;
            this.txt_idade.LineThickness = 3;
            this.txt_idade.Location = new System.Drawing.Point(120, 183);
            this.txt_idade.Margin = new System.Windows.Forms.Padding(4);
            this.txt_idade.Name = "txt_idade";
            this.txt_idade.Size = new System.Drawing.Size(246, 33);
            this.txt_idade.TabIndex = 23;
            this.txt_idade.TextAlign = System.Windows.Forms.HorizontalAlignment.Left;
            // 
            // label14
            // 
            this.label14.AutoSize = true;
            this.label14.Font = new System.Drawing.Font("Candara", 14.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label14.ForeColor = System.Drawing.Color.White;
            this.label14.Location = new System.Drawing.Point(44, 194);
            this.label14.Name = "label14";
            this.label14.Size = new System.Drawing.Size(61, 23);
            this.label14.TabIndex = 22;
            this.label14.Text = "IDADE";
            // 
            // txt_nome
            // 
            this.txt_nome.BackColor = System.Drawing.Color.White;
            this.txt_nome.Cursor = System.Windows.Forms.Cursors.IBeam;
            this.txt_nome.Font = new System.Drawing.Font("Century Gothic", 9.75F);
            this.txt_nome.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(64)))), ((int)(((byte)(64)))), ((int)(((byte)(64)))));
            this.txt_nome.HintForeColor = System.Drawing.Color.Empty;
            this.txt_nome.HintText = "";
            this.txt_nome.isPassword = false;
            this.txt_nome.LineFocusedColor = System.Drawing.Color.Blue;
            this.txt_nome.LineIdleColor = System.Drawing.Color.Gray;
            this.txt_nome.LineMouseHoverColor = System.Drawing.Color.Blue;
            this.txt_nome.LineThickness = 3;
            this.txt_nome.Location = new System.Drawing.Point(118, 77);
            this.txt_nome.Margin = new System.Windows.Forms.Padding(4);
            this.txt_nome.Name = "txt_nome";
            this.txt_nome.Size = new System.Drawing.Size(246, 33);
            this.txt_nome.TabIndex = 13;
            this.txt_nome.TextAlign = System.Windows.Forms.HorizontalAlignment.Left;
            this.txt_nome.OnValueChanged += new System.EventHandler(this.bunifuMaterialTextbox2_OnValueChanged);
            // 
            // label11
            // 
            this.label11.AutoSize = true;
            this.label11.Font = new System.Drawing.Font("Candara", 15.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label11.ForeColor = System.Drawing.Color.White;
            this.label11.Location = new System.Drawing.Point(140, 63);
            this.label11.Name = "label11";
            this.label11.Size = new System.Drawing.Size(231, 26);
            this.label11.TabIndex = 2;
            this.label11.Text = "ATUALIZAR CANDIDATO";
            // 
            // panel2
            // 
            this.panel2.BackColor = System.Drawing.Color.White;
            this.panel2.BackgroundImage = ((System.Drawing.Image)(resources.GetObject("panel2.BackgroundImage")));
            this.panel2.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.panel2.Location = new System.Drawing.Point(14, 17);
            this.panel2.Name = "panel2";
            this.panel2.Size = new System.Drawing.Size(107, 106);
            this.panel2.TabIndex = 1;
            // 
            // panel1
            // 
            this.panel1.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(0)))), ((int)(((byte)(30)))));
            this.panel1.Controls.Add(this.label11);
            this.panel1.Controls.Add(this.panel2);
            this.panel1.Location = new System.Drawing.Point(1, 0);
            this.panel1.Name = "panel1";
            this.panel1.Size = new System.Drawing.Size(427, 303);
            this.panel1.TabIndex = 27;
            // 
            // label10
            // 
            this.label10.AutoSize = true;
            this.label10.Font = new System.Drawing.Font("Candara", 14.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label10.ForeColor = System.Drawing.Color.White;
            this.label10.Location = new System.Drawing.Point(37, 87);
            this.label10.Name = "label10";
            this.label10.Size = new System.Drawing.Size(62, 23);
            this.label10.TabIndex = 12;
            this.label10.Text = "NOME";
            // 
            // panel3
            // 
            this.panel3.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(64)))), ((int)(((byte)(64)))), ((int)(((byte)(64)))));
            this.panel3.Controls.Add(this.label5);
            this.panel3.Controls.Add(this.btn_atualizar);
            this.panel3.Controls.Add(this.txt_idade);
            this.panel3.Controls.Add(this.label14);
            this.panel3.Controls.Add(this.cmb_cursos);
            this.panel3.Controls.Add(this.label4);
            this.panel3.Controls.Add(this.txt_nome);
            this.panel3.Controls.Add(this.label10);
            this.panel3.Controls.Add(this.N_ID);
            this.panel3.Location = new System.Drawing.Point(1, 140);
            this.panel3.Name = "panel3";
            this.panel3.Size = new System.Drawing.Size(427, 314);
            this.panel3.TabIndex = 28;
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.Font = new System.Drawing.Font("Candara", 14.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label4.ForeColor = System.Drawing.Color.White;
            this.label4.Location = new System.Drawing.Point(37, 135);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(68, 23);
            this.label4.TabIndex = 14;
            this.label4.Text = "CURSO";
            // 
            // label5
            // 
            this.label5.AutoSize = true;
            this.label5.Font = new System.Drawing.Font("Candara", 14.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label5.ForeColor = System.Drawing.Color.White;
            this.label5.Location = new System.Drawing.Point(37, 37);
            this.label5.Name = "label5";
            this.label5.Size = new System.Drawing.Size(122, 23);
            this.label5.TabIndex = 25;
            this.label5.Text = "Nº DE ORDEM";
            // 
            // AtualizarCandidato
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(11F, 25F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(426, 437);
            this.Controls.Add(this.panel3);
            this.Controls.Add(this.label1);
            this.Controls.Add(this.panel1);
            this.Font = new System.Drawing.Font("Yu Gothic UI", 14.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.Icon = ((System.Drawing.Icon)(resources.GetObject("$this.Icon")));
            this.Margin = new System.Windows.Forms.Padding(6);
            this.MaximizeBox = false;
            this.Name = "AtualizarCandidato";
            this.Text = "AtualizarCandidato";
            ((System.ComponentModel.ISupportInitialize)(this.N_ID)).EndInit();
            this.panel1.ResumeLayout(false);
            this.panel1.PerformLayout();
            this.panel3.ResumeLayout(false);
            this.panel3.PerformLayout();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.NumericUpDown N_ID;
        private System.Windows.Forms.ComboBox cmb_cursos;
        private MaterialSkin.Controls.MaterialRaisedButton btn_atualizar;
        private Bunifu.Framework.UI.BunifuMaterialTextbox txt_idade;
        private System.Windows.Forms.Label label14;
        private Bunifu.Framework.UI.BunifuMaterialTextbox txt_nome;
        private System.Windows.Forms.Label label11;
        private System.Windows.Forms.Panel panel2;
        private System.Windows.Forms.Panel panel1;
        private System.Windows.Forms.Label label10;
        private System.Windows.Forms.Panel panel3;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.Label label5;
    }
}